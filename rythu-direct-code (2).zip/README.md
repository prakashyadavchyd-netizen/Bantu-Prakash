# Rythu Direct
Responsive organic farmer-to-customer marketplace prototype in plain HTML, CSS and JavaScript.

## Run
Open dist/index.html or serve dist with any static web server. No build dependencies.

## Features
English, Telugu and Hindi primary shopping labels and product names; search and category filters; sorting; farmer profiles; basket with quantity controls; local demo order requests; location selector and optional geolocation; demo customer/farmer login; farmer profile and product creation; multilingual offline assistant with optional browser speech recognition.

## Important limitations
This is a frontend prototype, not a production commerce system. Catalogue and farmer profiles are sample data. Organic and owner claims are not independently verified. No SMS is sent; demo OTP is 123456 and does not authenticate anybody. No real orders, payments or messages are submitted. Farmer listings last for this browser session. Saved demo addresses stay on the device in localStorage. Some secondary form/help text is English.

## Production integration
1. Add a backend and database for users, farms, listings, inventory and orders, with server-enforced roles and resource ownership.
2. Replace demo OTP with Firebase Phone Auth or another verified SMS provider. Verify tokens server-side, rate-limit requests, expire codes and protect sessions. Never use the demo check for authentication.
3. Verify farm ownership and organic certification/evidence before approval. Provide traceable organic status per listing and moderation.
4. Replace offline assistant with a server-side Gemini API integration. Store the API key only in server secrets. Ground responses in approved catalogue data and require confirmation for order actions. The demo has no Google Assistant or Gemini connection.
5. Add service-area availability, delivery pricing, payments, refunds, consent, privacy controls and deletion for personal data.
6. Finish localization of all secondary text with a fluent reviewer.

## Files
- dist/index.html — page and dialog shell
- dist/style.css — responsive visual styling
- dist/app.js — catalogue, translations and demo workflows

Remote imagery: Unsplash. Browser fonts: Google Fonts. Remote resources need an internet connection; product image errors fall back to emoji.
